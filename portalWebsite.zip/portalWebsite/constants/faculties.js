module.exports = {
  eng_mechanical: 1,
  eng_electrical: 2,
  cs_se: 3,
  cs_ds: 4,
  cs_sec: 5,
};
