module.exports = {
  student: 1,
  admin: 2,
};
